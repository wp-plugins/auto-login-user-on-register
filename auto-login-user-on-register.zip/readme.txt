=== Auto Login User on Register ===
Plugin Name: Auto Login User on Register
Contributors: mboynes,alleyinteractive
Tags: user, registration, login, automatically login, autologin, auto login, settings, wp_options
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 5
Plugin URI: http://pkweb.ru/
Donate link: http://pkweb.ru/
Version: 1.0.0
Author: Penzin Konstantin
Email: penzin85@gmail.com

== Description ==
This plugin will automatically login your new user after the registration process.

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.0.0 =
* Initial release